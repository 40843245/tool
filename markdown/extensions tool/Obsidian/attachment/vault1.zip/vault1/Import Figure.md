### [Images that specifies the width or height etc](https://stackoverflow.com/questions/14675913/changing-image-size-in-markdown)

Let's look at images the size is **NOT** changed and its syntax first, then, look at images that the width or height is specified, and its syntax, through following exmaple.

> [!IMPORTANT]
> > They have same effect at Github. However, they may have different effect in different platforms.


+ Example 1: The size is **NOT** changed.

```
![CNAME_ex1](CNAME_ex1.jpg)
```

will render output looks like this:

![CNAME_ex1](CNAME_ex1.jpg)

+ Example 2:

```
![CNAME_ex1|20x100](CNAME_ex1.jpg)
```

will render output looks like this:

![CNAME_ex1|20x100](CNAME_ex1.jpg)

+ Example 3: 

```
![<img alt='CNAME_ex1' src='CNAME_ex1.jpg' width='20'/>](CNAME_ex1.jpg)
```

will render output looks like this:

![<img alt='CNAME_ex1' src='https://github.com/40843245/computer-science/blob/main/attachment/paradigm/CNAME_ex1.jpg' width='20'/>](CNAME_ex1.jpg)


+ Example 4: 

```
![<img alt='CNAME_ex1' width='20'/>](CNAME_ex1.jpg)
```

will render output looks like this:

![<img alt='CNAME_ex' width='20'/>](CNAME_ex1.jpg)

+ Example 5:

```
![CNAME_ex1\|20x100](CNAME_ex1.jpg)
```

will render output looks like this:

![CNAME_ex1\|20x100](CNAME_ex1.jpg)